# Test data for reconsult

Each file consists of a series of  sections, separated by a line holding
at least 4 %%%%, typically 16:

  ```
  %%%%%%%%%%%%%%%%
  ```

The source code for version  _N_  is   the  Nth  section, preceeded by a
module header.
