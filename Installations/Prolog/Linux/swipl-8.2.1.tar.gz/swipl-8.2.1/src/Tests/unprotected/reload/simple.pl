p1.

p2 :- a.
p2 :- b.

p3 :- a.
p3 :- b.
p3 :- c.

a.
b.
c.
