This directory contains a simple demo to   get you started. You can also
use this directory to develop your own  programs but this is not adviced
for serious usage. For normal usage, choose a location on the filesystem
that suits you best.

Windows
-------

On Windows platform use the extension associated to PLWIN.EXE choosen at
installation (default .PL) for Prolog  source   files  and load the main
file by double-clicking it in the Windows   explorer or dragging it onto
PLWIN.EXE or a shortcut to this executable   (you  can put a shortcut to
PLWIN.EXE on your desktop).

Unix
----

Normally you create your Prolog source  files using the extension `.pl`.
You start a program using

    % swipl -s file.pl

or ensuring the first line reads as   below  and make file.pl executable
using chmod +x file.pl. Adjust  /path/to/swipl   and  option ... to your
preferences and installation.

    #!/path/to/swipl

Further information (manual, mailing list, user web)
----------------------------------------------------

  - http://www.swi-prolog.org

