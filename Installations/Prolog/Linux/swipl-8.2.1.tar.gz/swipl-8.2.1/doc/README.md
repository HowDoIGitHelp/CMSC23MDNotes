# Design and maintenance documentation

This directory holds documents related to   design and maintenance. User
documentation is in the directory `man`  below   the  toplevel and for a
large part generated from PlDoc comments in the Prolog sources.

## Documents

 - Release.md
   Describes creating a new release.
